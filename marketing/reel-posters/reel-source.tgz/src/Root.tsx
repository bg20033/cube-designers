import { Composition } from "remotion"
import { PosterReel, TOTAL } from "./PosterReel"

export const Root = () => (
  <Composition
    id="PosterReel"
    component={PosterReel}
    durationInFrames={TOTAL}
    fps={30}
    width={1080}
    height={1920}
  />
)
