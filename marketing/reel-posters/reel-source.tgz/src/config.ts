// Edit this file to change posters, prices and copy.
// Images live in /public. To use the Higgsfield designs, drop them in
// public/higgsfield/ and point TRIO at them.

export const BRAND = {
  ink: "#0b0b0d",
  paper: "#f5f1e7",
  orange: "#f97316",
  muted: "#6b6760",
  handle: "@cube.designers",
}

export const PRICE = {
  format: "A3",
  single: 15,
  trio: 35,
  material: "Letër mat 250 g/m²",
}

// Posters that flash into the empty spot on the wall (scene 2), with labels.
export const FLASH: { src: string; label: string }[] = [
  { src: "c/kinema-gilda.jpg", label: "Kinema" },
  { src: "c/japoni-under-the-wave-off-kanagawa.jpg", label: "Art japonez" },
  { src: "c/vintage-jane-avril.jpg", label: "Vintage" },
  { src: "c/udhetim-cunard-line-europe-america.jpg", label: "Udhëtim" },
  { src: "c/klasike-the-bedroom.jpg", label: "Impresionistët" },
  { src: "c/kinema-king-kong.jpg", label: "Kinema" },
  { src: "c/muzike-folies-bergere.jpg", label: "Muzikë" },
  { src: "c/japoni-goldfish.jpg", label: "Art japonez" },
  { src: "c/kinema-metropolis.jpg", label: "Kinema" },
  { src: "c/udhetim-gstaad-royal-hotel-winter-palace-ski-bob.jpg", label: "Udhëtim" },
  { src: "c/vintage-moulin-rouge-la-goulue.jpg", label: "Vintage" },
  { src: "c/klasike-water-lilies.jpg", label: "Impresionistët" },
  { src: "c/udhetim-red-star-line.jpg", label: "Udhëtim" },
]

// Scrolling poster wall (scene 3): three columns.
export const WALL: string[][] = [
  [
    "c/kinema-dracula.jpg",
    "c/japoni-kanbara-evening-snow.jpg",
    "c/vintage-divan-japonais.jpg",
    "c/klasike-stacks-of-wheat.jpg",
    "c/kinema-the-african-queen.jpg",
  ],
  [
    "c/udhetim-red-star-line.jpg",
    "c/klasike-a-sunday-on-la-grande-jatte-1884.jpg",
    "c/kinema-frankenstein.jpg",
    "c/japoni-under-the-wave-off-kanagawa.jpg",
    "c/vintage-moulin-rouge-la-goulue.jpg",
  ],
  [
    "c/klasike-water-lilies.jpg",
    "c/kinema-gilda.jpg",
    "c/udhetim-cunard-line-europe-america.jpg",
    "c/klasike-the-bedroom.jpg",
    "c/kinema-king-kong.jpg",
  ],
]

// Hero poster for the single-price scene (scene 4).
export const HERO = "c/vintage-divan-japonais.jpg"

// Three posters for the bundle scene (scene 5).
export const TRIO: string[] = [
  "c/kinema-frankenstein.jpg",
  "c/kinema-dracula.jpg",
  "c/kinema-king-kong.jpg",
]
