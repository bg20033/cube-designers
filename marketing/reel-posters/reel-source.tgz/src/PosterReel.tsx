import "@fontsource-variable/roboto"
import "@fontsource-variable/inter"
import React, { useEffect, useState } from "react"
import {
  AbsoluteFill,
  Img,
  Sequence,
  continueRender,
  delayRender,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  Easing,
} from "remotion"
import { BRAND, FLASH, HERO, PRICE, TRIO, WALL } from "./config"

const HEAD = "'Roboto Variable', sans-serif"
const BODY = "'Inter Variable', sans-serif"

// Scene boundaries (frames @30fps)
const S1 = 0
const S2 = 75
const S3 = 225
const S4 = 330
const S5 = 450
const S6 = 555
export const TOTAL = 645

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const

const useSpring = (delay = 0, damping = 14, mass = 0.7) => {
  const frame = useCurrentFrame()
  const { fps } = useVideoConfig()
  return spring({ frame: frame - delay, fps, config: { damping, mass } })
}

// ---------- shared bits ----------

const Wall: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(120% 70% at 30% 20%, #fffaf0 0%, ${BRAND.paper} 45%, #e6dfcf 100%)`,
    }}
  >
    <svg width="1080" height="1920" style={{ position: "absolute", opacity: 0.35, mixBlendMode: "multiply" }}>
      <filter id="grain">
        <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="4" />
        <feColorMatrix values="0 0 0 0 0.45  0 0 0 0 0.4  0 0 0 0 0.33  0 0 0 0.25 0" />
      </filter>
      <rect width="1080" height="1920" filter="url(#grain)" />
    </svg>
    {children}
  </AbsoluteFill>
)

const Poster: React.FC<{
  src: string
  maxW: number
  maxH: number
  style?: React.CSSProperties
}> = ({ src, maxW, maxH, style }) => (
  <Img
    src={staticFile(src)}
    style={{
      maxWidth: maxW,
      maxHeight: maxH,
      display: "block",
      boxShadow: "0 30px 60px rgba(40,30,15,.28), 0 6px 14px rgba(40,30,15,.18)",
      ...style,
    }}
  />
)

const Headline: React.FC<{
  lines: { text: string; color?: string }[]
  top: number
  size?: number
  delay?: number
}> = ({ lines, top, size = 140, delay = 0 }) => {
  const frame = useCurrentFrame()
  return (
    <div style={{ position: "absolute", top, left: 80, right: 80 }}>
      {lines.map((l, i) => {
        const p = interpolate(frame - delay - i * 4, [0, 12], [0, 1], {
          ...clamp,
          easing: Easing.out(Easing.cubic),
        })
        return (
          <div key={i} style={{ overflow: "hidden", lineHeight: 1.02, paddingBottom: 6 }}>
            <div
              style={{
                fontFamily: HEAD,
                fontWeight: 900,
                fontSize: size,
                letterSpacing: -size * 0.035,
                color: l.color ?? BRAND.ink,
                transform: `translateY(${(1 - p) * 110}%)`,
              }}
            >
              {l.text}
            </div>
          </div>
        )
      })}
    </div>
  )
}

const Chip: React.FC<{ children: React.ReactNode; dark?: boolean; style?: React.CSSProperties }> = ({
  children,
  dark,
  style,
}) => (
  <div
    style={{
      fontFamily: BODY,
      fontWeight: 600,
      fontSize: 40,
      padding: "18px 34px",
      borderRadius: 999,
      background: dark ? BRAND.ink : "rgba(255,255,255,.7)",
      color: dark ? BRAND.paper : BRAND.ink,
      border: dark ? "none" : `2px solid rgba(11,11,13,.15)`,
      whiteSpace: "nowrap",
      ...style,
    }}
  >
    {children}
  </div>
)

// ---------- scenes ----------

// Spot on the wall where posters land (scenes 1 and 2)
const SPOT = { top: 700, height: 860, width: 640 }

const Scene1: React.FC = () => {
  const frame = useCurrentFrame()
  const appear = useSpring(10, 16)
  return (
    <Wall>
      <Headline top={300} lines={[{ text: "Muri yt" }, { text: "është bosh?", color: BRAND.orange }]} />
      <div
        style={{
          position: "absolute",
          top: SPOT.top,
          left: (1080 - SPOT.width) / 2,
          width: SPOT.width,
          height: SPOT.height,
          opacity: appear,
          transform: `scale(${0.92 + appear * 0.08}) rotate(${Math.sin(frame / 9) * 0.8}deg)`,
          transformOrigin: "50% 0%",
        }}
      >
        <svg width={SPOT.width} height={SPOT.height}>
          <rect
            x="4"
            y="4"
            width={SPOT.width - 8}
            height={SPOT.height - 8}
            fill="rgba(11,11,13,.03)"
            stroke="rgba(11,11,13,.35)"
            strokeWidth="5"
            strokeDasharray="26 20"
            strokeDashoffset={-frame * 1.5}
            rx="4"
          />
        </svg>
      </div>
      {/* nail */}
      <div
        style={{
          position: "absolute",
          top: SPOT.top - 38,
          left: 540 - 13,
          width: 26,
          height: 26,
          borderRadius: 13,
          background: "radial-gradient(circle at 35% 35%, #8a857c, #2a2824)",
          boxShadow: "2px 4px 6px rgba(0,0,0,.3)",
          opacity: appear,
        }}
      />
    </Wall>
  )
}

const PER = 11 // frames per poster in the flash sequence

const Scene2: React.FC = () => {
  const frame = useCurrentFrame()
  const idx = Math.min(FLASH.length - 1, Math.floor(frame / PER))
  const local = frame - idx * PER
  const hit = interpolate(local, [0, 5], [1, 0], { ...clamp, easing: Easing.out(Easing.quad) })
  const item = FLASH[idx]
  const first = idx === 0 ? interpolate(frame, [0, 8], [1, 0], clamp) : 0
  return (
    <Wall>
      <Headline top={300} lines={[{ text: "Gjej stilin" }, { text: "tënd.", color: BRAND.orange }]} />
      <AbsoluteFill
        style={{
          top: SPOT.top,
          height: SPOT.height,
          bottom: "auto",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            transform: `translateY(${-first * 120}px) scale(${1 + hit * 0.07}) rotate(${(idx % 2 ? 1 : -1) * hit * 2.5}deg)`,
          }}
        >
          <Poster src={item.src} maxW={SPOT.width} maxH={SPOT.height} />
        </div>
      </AbsoluteFill>
      <div
        style={{
          position: "absolute",
          top: SPOT.top + SPOT.height + 40,
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
        }}
      >
        <Chip dark style={{ background: BRAND.orange, color: BRAND.ink, fontWeight: 700 }}>
          {item.label}
        </Chip>
      </div>
    </Wall>
  )
}

const Scene3: React.FC = () => {
  const frame = useCurrentFrame()
  const colW = 330
  const gap = 34
  const card = useSpring(6, 15)
  return (
    <Wall>
      <div
        style={{
          position: "absolute",
          left: -170,
          top: -260,
          display: "flex",
          gap,
          transform: "rotate(-7deg) scale(1.08)",
        }}
      >
        {WALL.map((col, c) => {
          const dir = c % 2 === 0 ? -1 : 1
          const y = dir * frame * 4.2 + (dir > 0 ? -900 : 0)
          const items = [...col, ...col]
          return (
            <div key={c} style={{ display: "flex", flexDirection: "column", gap, transform: `translateY(${y}px)` }}>
              {items.map((src, i) => (
                <Img
                  key={i}
                  src={staticFile(src)}
                  style={{
                    width: colW,
                    display: "block",
                    boxShadow: "0 18px 34px rgba(40,30,15,.25)",
                  }}
                />
              ))}
            </div>
          )
        })}
        {/* fourth column re-uses the first for full coverage */}
        <div style={{ display: "flex", flexDirection: "column", gap, transform: `translateY(${frame * 4.2 - 900}px)` }}>
          {[...WALL[1], ...WALL[0]].map((src, i) => (
            <Img key={i} src={staticFile(src)} style={{ width: colW, display: "block", boxShadow: "0 18px 34px rgba(40,30,15,.25)" }} />
          ))}
        </div>
      </div>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div
          style={{
            background: BRAND.ink,
            color: BRAND.paper,
            padding: "56px 64px 60px",
            borderRadius: 18,
            width: 860,
            boxShadow: "0 40px 80px rgba(0,0,0,.35)",
            transform: `translateY(${(1 - card) * 140}px) scale(${0.9 + card * 0.1})`,
            opacity: card,
          }}
        >
          <div style={{ fontFamily: HEAD, fontWeight: 900, fontSize: 128, lineHeight: 1, letterSpacing: -4 }}>
            Qindra
            <br />
            <span style={{ color: BRAND.orange }}>dizajne.</span>
          </div>
          <div style={{ fontFamily: BODY, fontWeight: 500, fontSize: 40, marginTop: 30, opacity: 0.85, lineHeight: 1.35 }}>
            Kinema · Art japonez · Vintage
            <br />
            Udhëtim · Muzikë · Impresionistët
          </div>
        </div>
      </AbsoluteFill>
    </Wall>
  )
}

const PriceBadge: React.FC<{ value: string; size: number; delay: number; style?: React.CSSProperties }> = ({
  value,
  size,
  delay,
  style,
}) => {
  const s = useSpring(delay, 9, 0.6)
  return (
    <div
      style={{
        position: "absolute",
        width: size,
        height: size,
        borderRadius: size / 2,
        background: BRAND.orange,
        color: BRAND.ink,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: HEAD,
        fontWeight: 900,
        fontSize: size * 0.4,
        letterSpacing: -3,
        boxShadow: "0 20px 40px rgba(249,115,22,.35)",
        transform: `scale(${s}) rotate(${(1 - s) * -40 + 8}deg)`,
        ...style,
      }}
    >
      {value}
    </div>
  )
}

const Scene4: React.FC = () => {
  const frame = useCurrentFrame()
  const enter = useSpring(0, 13)
  const chips = interpolate(frame, [22, 34], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) })
  return (
    <Wall>
      <Headline
        top={280}
        size={130}
        lines={[{ text: `Poster ${PRICE.format}` }, { text: "për murin tënd.", color: BRAND.orange }]}
      />
      <AbsoluteFill style={{ top: 640, height: 820, bottom: "auto", alignItems: "center", justifyContent: "center" }}>
        <div
          style={{
            transform: `translateX(${(1 - enter) * 700}px) rotate(${-2 - (1 - enter) * 10}deg)`,
          }}
        >
          <Poster src={HERO} maxW={560} maxH={820} />
        </div>
      </AbsoluteFill>
      <PriceBadge value={`${PRICE.single}€`} size={290} delay={12} style={{ top: 600, right: 90 }} />
      <div
        style={{
          position: "absolute",
          top: 1510,
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
          gap: 20,
          opacity: chips,
          transform: `translateY(${(1 - chips) * 40}px)`,
        }}
      >
        <Chip>Formati {PRICE.format}</Chip>
        <Chip>{PRICE.material}</Chip>
      </div>
    </Wall>
  )
}

const Scene5: React.FC = () => {
  const frame = useCurrentFrame()
  const fan = useSpring(4, 14)
  const price = useSpring(20, 11)
  const strike = interpolate(frame, [32, 42], [0, 1], { ...clamp, easing: Easing.inOut(Easing.cubic) })
  const save = useSpring(44, 10)
  const pos = [
    { x: -245, r: -10, z: 0 },
    { x: 0, r: 0, z: 2 },
    { x: 245, r: 10, z: 1 },
  ]
  return (
    <Wall>
      <Headline top={280} size={124} lines={[{ text: "Merr 3," }, { text: "paguaj më pak.", color: BRAND.orange }]} />
      <div style={{ position: "absolute", top: 650, left: 0, right: 0, height: 640 }}>
        {TRIO.map((src, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 540,
              top: 0,
              zIndex: pos[i].z,
              transform: `translateX(-50%) translateX(${pos[i].x * fan}px) translateY(${Math.abs(pos[i].r) * fan * 3}px) rotate(${pos[i].r * fan}deg)`,
              transformOrigin: "50% 100%",
            }}
          >
            <Poster src={src} maxW={i === 1 ? 400 : 330} maxH={i === 1 ? 600 : 500} />
          </div>
        ))}
      </div>
      <div
        style={{
          position: "absolute",
          top: 1330,
          left: 0,
          right: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 36,
        }}
      >
        <div style={{ position: "relative", fontFamily: HEAD, fontWeight: 700, fontSize: 92, color: BRAND.muted, opacity: price }}>
          {PRICE.single * 3}€
          <div
            style={{
              position: "absolute",
              left: -6,
              top: "52%",
              height: 9,
              width: `${strike * 108}%`,
              background: BRAND.ink,
              transform: "rotate(-8deg)",
            }}
          />
        </div>
        <div
          style={{
            fontFamily: HEAD,
            fontWeight: 900,
            fontSize: 210,
            letterSpacing: -8,
            color: BRAND.orange,
            lineHeight: 1,
            transform: `scale(${price})`,
          }}
        >
          {PRICE.trio}€
        </div>
      </div>
      <div style={{ position: "absolute", top: 1560, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Chip dark style={{ transform: `scale(${save})` }}>
          3 posterë {PRICE.format} · kurse {PRICE.single * 3 - PRICE.trio}€
        </Chip>
      </div>
    </Wall>
  )
}

const Scene6: React.FC = () => {
  const frame = useCurrentFrame()
  const arcLen = 73.1
  const draw = interpolate(frame, [0, 18], [arcLen, 0], { ...clamp, easing: Easing.out(Easing.cubic) })
  const name = interpolate(frame, [10, 24], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) })
  const cta = useSpring(22, 11)
  const tail = interpolate(frame, [32, 44], [0, 1], clamp)
  const pulse = 1 + Math.max(0, Math.sin((frame - 40) / 5)) * 0.03 * (frame > 40 ? 1 : 0)
  return (
    <AbsoluteFill style={{ background: BRAND.ink, alignItems: "center" }}>
      <svg width="300" height="300" viewBox="0 0 64 64" style={{ position: "absolute", top: 380 }}>
        <path
          d="M42.96 21.04A15.5 15.5 0 1 0 42.96 42.96"
          fill="none"
          stroke={BRAND.orange}
          strokeWidth="10"
          strokeDasharray={arcLen}
          strokeDashoffset={draw}
        />
      </svg>
      <div
        style={{
          position: "absolute",
          top: 760,
          fontFamily: HEAD,
          fontWeight: 900,
          fontSize: 118,
          letterSpacing: -2,
          color: BRAND.paper,
          lineHeight: 1,
          textAlign: "center",
          opacity: name,
          transform: `translateY(${(1 - name) * 40}px)`,
        }}
      >
        CUBE
        <br />
        DESIGNERS
      </div>
      <div
        style={{
          position: "absolute",
          top: 1060,
          background: BRAND.orange,
          color: BRAND.ink,
          fontFamily: HEAD,
          fontWeight: 800,
          fontSize: 64,
          padding: "30px 64px",
          borderRadius: 999,
          transform: `scale(${cta * pulse})`,
        }}
      >
        Porosit në mesazh
      </div>
      <div
        style={{
          position: "absolute",
          top: 1240,
          fontFamily: BODY,
          fontWeight: 600,
          fontSize: 46,
          color: BRAND.paper,
          opacity: tail,
          textAlign: "center",
          lineHeight: 1.5,
        }}
      >
        {BRAND.handle}
        <div style={{ fontWeight: 500, fontSize: 38, opacity: 0.7 }}>
          Poster {PRICE.format} {PRICE.single}€ · 3 posterë {PRICE.trio}€
        </div>
      </div>
    </AbsoluteFill>
  )
}

// Short orange wipe between scenes
const Wipe: React.FC = () => {
  const frame = useCurrentFrame()
  const x = interpolate(frame, [0, 10], [-1100, 1100], { ...clamp, easing: Easing.inOut(Easing.cubic) })
  return (
    <AbsoluteFill
      style={{
        background: BRAND.orange,
        transform: `translateX(${x}px) skewX(-12deg)`,
        width: 1300,
        left: -110,
      }}
    />
  )
}

export const PosterReel: React.FC = () => {
  const [handle] = useState(() => delayRender("fonts"))
  useEffect(() => {
    Promise.all([
      document.fonts.load("900 100px 'Roboto Variable'", "ëç€"),
      document.fonts.load("600 40px 'Inter Variable'", "ëç€"),
    ])
      .then(() => document.fonts.ready)
      .then(() => continueRender(handle))
  }, [handle])

  return (
    <AbsoluteFill style={{ background: BRAND.paper }}>
      <Sequence from={S1} durationInFrames={S2 - S1}>
        <Scene1 />
      </Sequence>
      <Sequence from={S2} durationInFrames={S3 - S2}>
        <Scene2 />
      </Sequence>
      <Sequence from={S3} durationInFrames={S4 - S3}>
        <Scene3 />
      </Sequence>
      <Sequence from={S4} durationInFrames={S5 - S4}>
        <Scene4 />
      </Sequence>
      <Sequence from={S5} durationInFrames={S6 - S5}>
        <Scene5 />
      </Sequence>
      <Sequence from={S6} durationInFrames={TOTAL - S6}>
        <Scene6 />
      </Sequence>
      {[S3, S4, S5, S6].map((s) => (
        <Sequence key={s} from={s - 5} durationInFrames={11}>
          <Wipe />
        </Sequence>
      ))}
    </AbsoluteFill>
  )
}
