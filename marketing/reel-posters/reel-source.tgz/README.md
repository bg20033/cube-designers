# Cube Designers – Reel posterësh (Remotion)

    npm install
    npx remotion studio src/index.ts      # preview
    npx remotion render src/index.ts PosterReel out/reel.mp4

Posters, prices and copy: src/config.ts. Images: public/c/.
To use the Higgsfield designs: put them in public/higgsfield/ and point TRIO (or HERO) at them.
